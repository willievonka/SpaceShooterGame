﻿
using var game = new SpaceShooterGame.Game1();
game.Run();
